import { afterAll, afterEach, beforeEach, describe, expect, it } from 'bun:test'
import { existsSync, rmSync } from 'node:fs'
import { join } from 'node:path'

import { DiscordCredentialManager } from './credential-manager'

const testDirs: string[] = []
let savedEnv: { token?: string; serverId?: string }

function setup(): DiscordCredentialManager {
  const testConfigDir = join(
    import.meta.dir,
    `.test-discord-config-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  )
  testDirs.push(testConfigDir)
  return new DiscordCredentialManager(testConfigDir)
}

beforeEach(() => {
  savedEnv = {
    token: process.env.E2E_DISCORD_TOKEN,
    serverId: process.env.E2E_DISCORD_SERVER_ID,
  }
  delete process.env.E2E_DISCORD_TOKEN
  delete process.env.E2E_DISCORD_SERVER_ID
})

afterEach(() => {
  if (savedEnv.token !== undefined) process.env.E2E_DISCORD_TOKEN = savedEnv.token
  else delete process.env.E2E_DISCORD_TOKEN
  if (savedEnv.serverId !== undefined) process.env.E2E_DISCORD_SERVER_ID = savedEnv.serverId
  else delete process.env.E2E_DISCORD_SERVER_ID
})

afterAll(() => {
  for (const dir of testDirs) {
    rmSync(dir, { recursive: true, force: true })
  }
})

describe('DiscordCredentialManager', () => {
  it('load returns default config when file does not exist', async () => {
    const manager = setup()
    const config = await manager.load()

    expect(config).toEqual({
      token: null,
      current_server: null,
      servers: {},
    })
  })

  it('save creates config file with correct permissions', async () => {
    const testConfigDir = join(
      import.meta.dir,
      `.test-discord-config-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    )
    testDirs.push(testConfigDir)
    const manager = new DiscordCredentialManager(testConfigDir)
    const config = {
      token: 'test-token',
      current_server: 'server-123',
      servers: {
        'server-123': { server_id: 'server-123', server_name: 'Test Server' },
      },
    }

    await manager.save(config)

    const credentialsPath = join(testConfigDir, 'discord-credentials.json')
    expect(existsSync(credentialsPath)).toBe(true)

    const file = Bun.file(credentialsPath)
    const content = await file.text()
    const loaded = JSON.parse(content)
    expect(loaded).toEqual(config)
  })

  it('getToken returns null when not authenticated', async () => {
    const manager = setup()
    const token = await manager.getToken()
    expect(token).toBeNull()
  })

  it('setToken saves token to config', async () => {
    const manager = setup()
    await manager.setToken('test-token-123')

    const token = await manager.getToken()
    expect(token).toBe('test-token-123')
  })

  it('getToken returns previously set token', async () => {
    const manager = setup()
    await manager.setToken('my-token')

    const token = await manager.getToken()
    expect(token).toBe('my-token')
  })

  it('clearToken removes token from config', async () => {
    const manager = setup()
    await manager.setToken('test-token')
    await manager.clearToken()

    const token = await manager.getToken()
    expect(token).toBeNull()
  })

  it('getCurrentServer returns null when not set', async () => {
    const manager = setup()
    const server = await manager.getCurrentServer()
    expect(server).toBeNull()
  })

  it('setCurrentServer saves server id', async () => {
    const manager = setup()
    await manager.setCurrentServer('server-456')

    const server = await manager.getCurrentServer()
    expect(server).toBe('server-456')
  })

  it('getServers returns empty object when no servers set', async () => {
    const manager = setup()
    const servers = await manager.getServers()
    expect(servers).toEqual({})
  })

  it('setServers saves servers to config', async () => {
    const manager = setup()
    const servers = {
      'server-1': { server_id: 'server-1', server_name: 'Server One' },
      'server-2': { server_id: 'server-2', server_name: 'Server Two' },
    }

    await manager.setServers(servers)

    const loaded = await manager.getServers()
    expect(loaded).toEqual(servers)
  })

  it('getCredentials returns null when not authenticated', async () => {
    const manager = setup()
    const creds = await manager.getCredentials()
    expect(creds).toBeNull()
  })

  it('getCredentials returns null when token exists but no server selected', async () => {
    const manager = setup()
    await manager.setToken('test-token')

    const creds = await manager.getCredentials()
    expect(creds).toBeNull()
  })

  it('getCredentials returns null when server selected but no token', async () => {
    const manager = setup()
    await manager.setCurrentServer('server-123')

    const creds = await manager.getCredentials()
    expect(creds).toBeNull()
  })

  it('getCredentials returns token and serverId when both are set', async () => {
    const manager = setup()
    await manager.setToken('test-token-xyz')
    await manager.setCurrentServer('server-789')

    const creds = await manager.getCredentials()
    expect(creds).toEqual({
      token: 'test-token-xyz',
      serverId: 'server-789',
    })
  })

  it('multiple operations preserve existing data', async () => {
    const manager = setup()
    await manager.setToken('token-1')
    await manager.setCurrentServer('server-1')
    const servers = {
      'server-1': { server_id: 'server-1', server_name: 'Server One' },
    }
    await manager.setServers(servers)

    await manager.setToken('token-2')

    expect(await manager.getToken()).toBe('token-2')
    expect(await manager.getCurrentServer()).toBe('server-1')
    expect(await manager.getServers()).toEqual(servers)
  })
})
